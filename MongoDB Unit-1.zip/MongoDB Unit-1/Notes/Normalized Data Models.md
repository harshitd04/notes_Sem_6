- Describe relationships using references b/w docs.

**Uses:**
- Embedding results in duplication of data but would not provide sufficient read performance adv to outweigh implications of duplication.
- to represent more complex many-to-many relationships.
- to model large hierarchical data sets.

