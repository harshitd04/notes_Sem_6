- Effective data models support your application needs.
- the key consideration for structure of your document is the decision 
	1. Embed
	2. Use References.