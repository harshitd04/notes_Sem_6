- Works best for unstructured data and hence Big Data systems, MapReduce applications, news site forums and social networking applications.

- Use MongoDB when:
1. Cloud computing cuz it needs to easily distribute data across multiple servers.
2. You need your data fast and easily accessible. When you are running performance critical applications.
3. You don't have database administrator. Ting business/start-up - less budget
4. Lots of unstructured data. Has no storable data type limits.
5. Using Agile metho. doesn't require high level of preparation like SQL.
6. Unstable or undefined schema.