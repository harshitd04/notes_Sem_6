1. You need ACID compliance like database-level transactions.
     (Atomicity, Consistency, Isolation, Durability.)
2. Work with stored procedures cuz it has no provision.
3. Data is unchanging and structured. 