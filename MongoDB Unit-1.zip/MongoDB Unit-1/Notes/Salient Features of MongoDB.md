1. General-Purpose Database
2. Flexible Schema Design
3. Load Balancing and Stability
4. Aggregation Framework
5. Native Replication
6. Security Features
7. JSON
8. MapReduce