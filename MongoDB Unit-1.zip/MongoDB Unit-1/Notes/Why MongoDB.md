1. Flexibility
2. Flexible Query Model
3. Native Aggregation
4. Schema-less Model
