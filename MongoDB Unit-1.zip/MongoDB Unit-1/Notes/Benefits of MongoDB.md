1. Cheaper, easier to maintain. Has easier data distribution, simpler data models & automatic repair i.e., require less administrative costs.
2. Open-source; They use cheaper servers, hence price of data storage and processing/gig is lower.
3. Easily and highly scalable. Expand Horizontally, can add more machines.
4. Supports integrated caching. System memory caching boosts data output performance.
5. Has no schema hassles. No predefined schema, change data model & formats without disrupting applications.
6. User-Friendly. Has file storage, indexing, load balancing, replication, aggregation etc.