For Databases
- Windows 
	/ \ . " $ * | ?
- Unix or Linux
   / \ . " $
- Cannot contain Null characters
- Cannot be empty.
- Less than 64 characters

For collections
- start with _ or character
- No $, empty string, null character, system prefix
- Max length 120 bytes. (including database name, dot separator and collection name.)

For Docs
- field name are of strings.
- _id field name is reserved as primary key. Can not be array.
- Field name != null characters.
- Top level field names should not start with $
