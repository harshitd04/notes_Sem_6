1. Product data management
2. Operational Intelligence
3. Product Catalog
4. Scaling and application mobility
5. Customer analytics
6. Mainframe Offloading
7. Rest-Time Data Integration
