- Also called Denormalized model.
- You may embed relation data in single structure or document.
- Docs size must be smaller than Max BSON size.
- For bulk binary data use **GridFs**.

**Uses:**
- You have "contains" relationships between entities. One to One Relationships.
- One to Many relationships between entities.