```json
$lookup
$graphLookup
```


- can use referencing to join data across collections.