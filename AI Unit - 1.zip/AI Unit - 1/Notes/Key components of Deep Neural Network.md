1. Input Layer
2. Hidden Layer
3. Output Layer
4. Weights and Biases
5. Activation Functions
6. Loss Functions