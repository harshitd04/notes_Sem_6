1. Shallow Neural Network
2. Deep NN
3. Recurrent NN
