1. Gradient Descent (GD)
2. Stochastic Gradient Descent (SGD)
3. Mini-Batch Gradient Descent 
4. Momentum
5. Nesterov Accelerated Gradient (NAG)
6. Adagrad
7. RMSprop
8. Adam (Adaptive Moment Estimation)