1. Mean Squared Error (MSE)
2. Mean Absolute Error (MAE)
3. Binary Cross Entropy Loss
4. Categorical Cross Entropy Loss
5. Sparse Categorical Cross Entropy Loss