1. Sigmoid
2. Softmax
3. Tanh (Hyberbolic Tangent)
4. ReLU (Rectified Linear Unit)
5. Leaky ReLU
6. Parametric Relu (PReLU)