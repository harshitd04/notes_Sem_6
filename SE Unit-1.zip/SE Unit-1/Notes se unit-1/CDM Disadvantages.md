1. Inflexibility
2. Late Testing
3. High Risk
4. Not Ideal for Complex Projects
5. Longer Delivery Time