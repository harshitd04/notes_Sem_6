For preventing software crises, there are some guidelines: 
1. Reduction in software over budget. 
2. The quality of the software must be high. 
3. Less time is needed for a software project. 
4. Experienced and skilled people working on the software project. 
5. Software must be delivered. 
6. Software must meet user requirements.