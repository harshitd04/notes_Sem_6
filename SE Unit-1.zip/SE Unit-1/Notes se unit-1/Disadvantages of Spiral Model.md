1. Complex: The Spiral Model is much more complex than other SDLC models. 
2. Expensive: Spiral Model is not suitable for small projects as it is expensive. 
3. Too much dependability on Risk Analysis: The successful completion of the project is very much dependent on Risk Analysis. Without very highly experienced experts, it is going to be a failure to develop a project using this model. 
4. Difficulty in time management: As the number of phases is unknown at the start of the project, time estimation is very difficult. 
5. Complexity: The Spiral Model can be complex, as it involves multiple iterations of the software development process. 
6. Time-Consuming: The Spiral Model can be time-consuming, as it requires multiple evaluations and reviews. 
7. Resource Intensive: The Spiral Model can be resource-intensive, as it requires a significant investment in planning, risk analysis, and evaluations.