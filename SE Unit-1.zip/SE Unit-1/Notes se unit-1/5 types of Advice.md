1. Before : Executed before the method call. 
2. After : Executed after the method call, regardless of its outcome. 
3. AfterReturning : Executed after the method returns a result, but not if an exception occurs. 
4. Around : Surrounds the method execution, allowing you to control the method execution and its result. 
5. AfterThrowing : Executed if the method throws an exception.