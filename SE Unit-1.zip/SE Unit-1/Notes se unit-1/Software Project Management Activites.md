1. Project planning and Tracking 
2. Project Resource Management 
3. Scope Management 
4. Estimation Management
5. Project Risk Management 
6. Scheduling Management
7. Project Communication Management 
8. Configuration Management