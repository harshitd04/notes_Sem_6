1. Risks Identification.
2. Risk Assessment. 
3. Risks Planning. 
4. Risk Monitoring


Classification:
1. Technical Risk
2. Business Risk
3. Project Risk