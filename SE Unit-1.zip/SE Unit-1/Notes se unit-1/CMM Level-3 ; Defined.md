1. At this level, documentation of the standard guidelines and procedures takes place.
2. Peer Reviews: In this method, defects are removed by using several review methods like walkthroughs, inspections, buddy checks, etc.
3. Intergroup Coordination: It consists of planned interactions between different development teams to ensure efficient and proper fulfillment of customer needs.
4. Organization Process Definition: Its key focus is on the development and maintenance of standard development processes.
5. Organization Process Focus: It includes activities and practices that should be followed to improve the process capabilities of an organization.
6. Training Programs: It focuses on the enhancement of knowledge and skills of the team members including the developers and ensuring an increase in work efficiency.