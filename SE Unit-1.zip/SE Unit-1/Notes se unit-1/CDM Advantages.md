1. Simple and Easy to Understand.
2. Well-Defined Stages
3. Documentation-centric
4. Easy to Manage
5. Structured Process