Similar to Spiral Model
![[Pasted image 20250323181351.png]]