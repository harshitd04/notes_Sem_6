1. At this stage, quantitative quality goals are set for the organization for software products as well as software processes.
2. The measurements made help the organization to predict the product and process quality within some limits defined quantitatively.
3. Software Quality Management: It includes the establishment of plans and strategies to develop quantitative analysis and understanding of the product’s quality.
4. Quantitative Management: It focuses on controlling the project performance quantitatively.
