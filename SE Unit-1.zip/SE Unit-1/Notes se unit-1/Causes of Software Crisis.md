Causes of Software Crisis: 
1. The cost of owning and maintaining software was as expensive as developing the software.
2. At that time Projects were running overtime. 
3. At that time Software was very inefficient. 
4. The quality of the software was low quality. 
5. Software often did not meet user requirements. 
6. The average software project overshoots its schedule by half.
7. At that time Software was never delivered.
8. Non-optimal resource utilization. 
9. Challenging to alter, debug, and enhance. 
10. The software complexity is harder to change.