1. Focuses on establishing basic project management policies.
2. Experience with earlier projects is used for managing new similar-natured projects.
3. Project Planning- It includes defining resources required, goals, constraints. 
4. Configuration Management- The focus is on maintaining the performance of the software product.
5. Requirements Management- It includes the management of customer reviews and feedback which result in some changes in the requirement set.
6. Subcontract Management- It focuses on the effective management of qualified software contractors.
7. Software Quality Assurance