![[Pasted image 20250323152519.png]]
![[Pasted image 20250323152547.png]]