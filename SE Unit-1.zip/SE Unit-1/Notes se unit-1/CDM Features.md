1. Parallel Workflow
2. Real-time Communication
3. Flexibility
4. Iterative Development
5. Reduced Time-to-Market