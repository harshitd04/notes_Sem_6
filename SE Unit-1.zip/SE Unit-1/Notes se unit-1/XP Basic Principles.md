1. Coding
2. Testing
3. Listening
4. Designing
5. Feedback
6. Simplicity
7. Pair Programming
8. Continuous Integration
9. Refactoring 
10. Collective Code Ownership
11. Planning Game
12. On-site Customer
 Extra:
 13. Respect
 14. Courage
 