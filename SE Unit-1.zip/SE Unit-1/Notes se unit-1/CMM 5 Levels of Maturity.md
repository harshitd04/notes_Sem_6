1. Initial
2. Repeatable
3. Defined
4. Managed
5. Optimizing