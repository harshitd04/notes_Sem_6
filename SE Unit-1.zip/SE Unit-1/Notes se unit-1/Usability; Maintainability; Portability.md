**Usability**: It refers to the extent to which the software can be used with ease. the amount of effort or time required to learn how to use the software.

**Maintainability**:It refers to the ease with which modifications can be made in a software system to extend its functionality, improve its performance, or correct errors.

**Portability**: A set of attributes that bears on the ability of software to be transferred from one environment to another, without minimum changes.