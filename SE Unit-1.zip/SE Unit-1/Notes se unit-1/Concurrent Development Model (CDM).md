1. Is a model in software engineering where more than one phase in a project is under development at any one time instead of one phase at a time.
2. Eg: Waterfall Model