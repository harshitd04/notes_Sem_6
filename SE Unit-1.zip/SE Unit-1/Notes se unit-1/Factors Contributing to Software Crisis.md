Factors Contributing to Software Crisis:
1. Poor project management. 
2. Lack of adequate training in software engineering.
3. Less skilled project members.
4. Low productivity improvements.