1. Optimization of Resources
2. Comparing and Evaluating
3. Management of Quality
4. Enhancement of Process
5. Increased Output