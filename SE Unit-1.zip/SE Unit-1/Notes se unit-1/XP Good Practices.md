1. Code Review
2. Testing
3. Incremental Development
4. Simplicity
5. Design
6. Integration Testing