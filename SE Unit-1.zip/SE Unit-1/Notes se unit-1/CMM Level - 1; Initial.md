Level-1: Initial
• No KPIs (Key Process Areas) defined. 
• Unstable environment for software development.
• No basis for predicting product quality, time for completion, etc. 
• Limited project management capabilities, such as no systematic tracking of schedules, budgets, or progress.
• We have limited communication and coordination among team members and stakeholders. 
• No formal training or orientation for new team members.
• Little or no use of software development tools or automation. 
• Highly dependent on individual skills and knowledge rather than standardized processes. 
• High risk of project failure or delays due to a lack of process control and stability.