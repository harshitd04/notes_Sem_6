1. In AOP, these cross-cutting concerns are modularized into separate units called aspects .
2. Cross cutting concerns are aspects of a program that affect multiple parts of the application, such as logging, security, or transaction management.
3. Dominant AOP Frameworks:
	1. AspectJ
	2. JBoss AOP
	3. Spring AOP
4. **Advice** : This is the action taken by an aspect at a particular join point. There are five types of advice: