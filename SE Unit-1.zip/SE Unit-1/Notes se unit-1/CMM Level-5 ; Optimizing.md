1. This is the highest level of process maturity in CMM and focuses on continuous process improvement in the organization using quantitative feedback.
2. The use of new tools, techniques, and evaluation of software processes is done to prevent the recurrence of known defects.
3. Process Change Management: Its focus is on the continuous improvement of the organization’s software processes to improve productivity, quality, and cycle time for the software product.
4. Technology Change Management: It consists of the identification and use of new technologies to improve product quality and decrease product development time.
5. Defect Prevention It focuses on the identification of causes of defects and prevents them from recurring in future projects by improving project-defined processes.
