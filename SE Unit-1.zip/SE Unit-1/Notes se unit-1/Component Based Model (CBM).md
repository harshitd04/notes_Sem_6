1. The component-based assembly model uses object-oriented technologies.
2. This model uses various characteristics of spiral model.

Steps of Working:
Step-1: First identify all the required candidate components.
Step-2: If these candidate components are used in previous software projects then they must be present in the library. 
Step-3: Such pre-existing components can be excited from the library and used for further development. 
Step-4: But if the required component is not present in the library then build or create the component as per requirement. 
Step-5: Place this newly created component in the library. This makes one iteration of the system. Step-6: Repeat steps 1 to 5 for creating n iterations.