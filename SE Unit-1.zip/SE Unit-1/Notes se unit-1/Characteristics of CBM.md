 1. Uses object-oriented technology.
 2. Components and classes encapsulate both data and algorithms.
 3. Components are developed to be reusable.
 4. Paradigm similar to spiral model, but engineering activity involves components. 
 5. The system produced by assembling the correct components.