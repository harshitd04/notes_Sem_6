1. Planning for execution of policies and programmes of top manag.
2. Analysing achievement of lower levels.
3. Discussing solutions to current problems and proceeding with their results.
4. Appraising performance of sub-units.
5. Achieving coordination between different sections or units.