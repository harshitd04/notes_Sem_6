[Not much imp to Human Relationship]
1. Hawthorne Experiments by Elton Mayo
2. Need Hierarchy theory by Abraham Maslow
3. Theory X and Y by Douglas McGregor 
	[Y: Self Motivated, can do their own work.]