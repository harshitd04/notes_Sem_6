1. Laying down broad objectives of the org
2. Co-ordination of various depart. and divisions.
3. Taking decisions for accomplishment of goals
4. Laying down guidelines for departs.
5. Making appointments to middle levels positions in org
6. Reviewing the work of executives at different levels to
    ensure performance.