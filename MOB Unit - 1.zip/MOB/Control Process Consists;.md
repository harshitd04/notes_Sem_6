1. Setting up of standards
2. Measuring of Performance
3. Comparing Performance with standards
4. Taking corrective action