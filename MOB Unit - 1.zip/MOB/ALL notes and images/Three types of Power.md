Three types of Power:
1. Charismatic power or domination
2. Traditional Power or domi.
3. Rational-legal power or domi.