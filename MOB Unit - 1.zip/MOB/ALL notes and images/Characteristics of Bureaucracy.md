Characteristics of Bureaucracy:
1. Division of Work
2. Impersonal Conduct
3. Hierarchy of Positions
4. Rules and Regulations
5. Staffing or Administrative Machinery
6. Technical Competence 
7. Official Records
