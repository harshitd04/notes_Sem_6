Conclusions of Hawthorne Experiments;
1. An org is not only Techno-economic system but also a psychosocial system.
2. Physical conditions of work exercise some influence on workers' morale and productivity.
   But Inter-personal relations, attitudes of supervisor and other psychological factors are more imp.
3. Workers spontaneously form small informal groups
4. Generally workers act or react as members of a group and not as individuals.
5. Informal Leaders play an important role in setting and enforcing group norms.
6. Workers are not mere economic beings motivated by money alone. Work situations matters.