Salient Features of Human Relations/Neo-Classical Approach:
1. Social System
2. Social Environment
3. Informal Organisation
4. Group Dynamics
5. Leardership
6. Communication
7. Role of Money
8. Conflict
