Principles of Scientific Management:
1. Science, not rule of thumb
2. Harmony, not discord
3. Cooperation, not individualism
4. Maximum output in place or restricted output.
5. Development of each man to his greatest efficiency and prosperity.
6. Equitable division of work and responsibility between management and labour.