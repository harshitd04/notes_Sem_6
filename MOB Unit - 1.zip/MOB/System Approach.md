1. Open System
2. Closed System
[Depends on if a factor affects the company]