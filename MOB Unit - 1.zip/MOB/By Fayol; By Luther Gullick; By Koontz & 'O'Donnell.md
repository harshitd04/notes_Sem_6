**Fayol**:
1. to forecast and plan,
2. to organise,
3. to command or to give orders,
4. to co-ordinate, and 
5. to control.

**Luther**: PODSCORB
Planning Organisation Directing Staffing Co-ordinating Reporting Budgeting.

**Koontz & 'O' Donnell:**
1. Planning
2. Organising 
3. Staffing
4. Directing
5. Controlling