![[Pasted image 20250322123836.png]]

![[Pasted image 20250322123949.png]]
