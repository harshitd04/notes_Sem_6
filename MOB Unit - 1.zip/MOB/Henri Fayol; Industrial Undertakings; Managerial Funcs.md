**Managerial Functions POCCC:**
1. Planning 
2. Organising
3. Commanding
4. Co-ordinating
5. Controlling

**Industrial Undertakings:**
1. Technical
2. Commercial
3. Financial
4. Security
5. Accounting 
6. Managerial 