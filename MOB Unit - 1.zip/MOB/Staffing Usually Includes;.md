1. Human resource planning.
2. Deciding sources of recruitment
3. Receiving Applications
4. Testing and Interviewing
5. Final Selection and appointment letter
6. Orientation and Placement 
7. Training and Development