1. Management Attitude 
2. Humanising the Organisation
3. Interiorizing Management
4. Self-Introspection
5. By-Stilling (Decision-making in silence)
6. Stepping Back(for a while)
7. Self-dynamising Meditation
8. Role of Intuitions in Management








