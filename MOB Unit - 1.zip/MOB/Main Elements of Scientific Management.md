1. Determination of the task
2. Planning of industrial operations
3. Proper selection, placement and
    training of workers
4. Improvements in methods of works
	1. standardization of tools & equipment.
	2. Regulation of speed of machines
	3. Improvement of work environment
5. Introduction of functional organization
6. Mental Revolution