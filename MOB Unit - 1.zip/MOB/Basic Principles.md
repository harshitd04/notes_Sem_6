There are six basic principles which are derived from our holy books and are applied in today’s management world. They are:

•Each soul is a potential of God.

•Holistic Approach.

•Equal importance to subjectivity & objectivity.

•Karma Yoga.

•Yogah Karmasu Kaushalam

•Co-operation