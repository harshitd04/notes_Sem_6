1. To supervise and guide work-force.
2. To plan and organize activities of group.
3. To arrange necessary necessary materials, tools for workers
	and provide them necessary working env.
4. To provide training for workforce.
5. To solve problems of workers.
6. To communicate workers problems to higher level manag.