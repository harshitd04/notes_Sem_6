1. Management Science
2. Operational Management
3. Management Information System