Management is that process by which managers create, direct, maintain and operate purposive organisations through systematic, coordinated, cooperative human effort.

Management Process 
![[Pasted image 20250322125124.png]]

