1. Determination of objectives
2. Identifications and grouping of activities
3. Assignment of duties to individuals 
4. Development of relationships.