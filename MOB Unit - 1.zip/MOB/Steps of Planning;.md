1. Determinations of objectives
2. Forecasting
3. Formulation of policies and programmers
4. Preparation of policies and procedures  
5. Budgeting