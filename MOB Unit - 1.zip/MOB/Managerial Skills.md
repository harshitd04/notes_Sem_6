By R.L. Katz
1. Technical Skills
2. Human Skills
3. Conceptual Skills

Other 2 added by other authors
4. Analytical Skills
5. Administrative Skills
