[Each soul is](https://www.slideshare.net/slideshow/insights-from-indian-practices-and-ethos/56177835) a potential of God:

A human being has a soul , a spark of the Divine. The Divine resides in the heart of the person. We all can say that a human being has immense potential for his self-development. A partnership between Man and God can bring impossible work into reality. But a man can achieve all this only if he works according to the god. He should be fair to the society without being injustice to other. Yes we all know that “GOD HELP ONLY THOSE WHO HELP THEMSELVES”

. [Holistic Approach:](https://www.slideshare.net/slideshow/insights-from-indian-practices-and-ethos/56177835)

 [](https://www.slideshare.net/slideshow/insights-from-indian-practices-and-ethos/56177835)[Holistic approach](https://www.slideshare.net/slideshow/insights-from-indian-practices-and-ethos/56177835) refers to all Humanity in One. It refers to the principle of unity, the whole universe in an undivided world. It refers to the unity which means connection of every particle with each other. Such an integrated human personality of self-developed manager and worker can assure best and competent management of any enterprise, involving collective works and efforts.

[Equal importance to subjectivity](https://www.slideshare.net/slideshow/insights-from-indian-practices-and-ethos/56177835) & objectivity:

 Indian ethos for management distinguishes between subject and object. Subject is subtle and intangible whereas Object is concrete and tangible . We have the concept of the third eye, the eye of wisdom. It see’s even the things which the normal eyes don’t. It can see the subject i.e. invisible. Human and ethical values or qualities such as courage, vision, social awareness, fearlessness, integrity, pure and clear mind, truth, etc are subjective, subtle and intangible concepts. These subjective qualities are as important as money, materials, machines, information or data or even human skills. Inner resources of human beings are more powerful than external resources. “Creator is subjective.”

Wisdom of manager/ worker is much more important and valuable than knowledge of manager/ worker. Therefore, manager must develop his third eye, ‘Jnana Chakhu’ , the eye of Vision intution, insight, foresight and such other divine qualities or values. This is the essence of Indian ethos for management.

 [Karma Yoga](https://www.slideshare.net/slideshow/insights-from-indian-practices-and-ethos/56177835)

 [](https://www.slideshare.net/slideshow/insights-from-indian-practices-and-ethos/56177835)[It is](https://www.slideshare.net/slideshow/insights-from-indian-practices-and-ethos/56177835) yoga of selfless service to others. Karma Yoga is all about identifying your priorities and trying to achieve them. Also, a person should have accountability i.e. he should always hold only himself responsible for whatever goes right or wrong. This brings about the union of human being with the Divine.

Gita says that do your duty without ego and without calculations of gain or loss. One should believe in Nishkama Karma i.e. fruits of work should not be thought of while performing the duty.

The memorable words of Gita are “ To work only you have the right and you have no right to the fruits of work”. However, this does not mean that one should work day and night and the returns that he gets should be almost negligible. What the Gita tries to say is that let not the fruits of action motivate you as they might just divert your attention from work. When you are doing a job, put your heart and soul in to it. One has no control over the future hence never waste your present in useless dreams of future hopes and fears of present actions. WHY DO I WORK? 1.For my own salvation and personal growth. 2.For the good of the world.

 [Yogah](https://www.slideshare.net/slideshow/insights-from-indian-practices-and-ethos/56177835) [](https://www.slideshare.net/slideshow/insights-from-indian-practices-and-ethos/56177835)[Karmasu](https://www.slideshare.net/slideshow/insights-from-indian-practices-and-ethos/56177835) [](https://www.slideshare.net/slideshow/insights-from-indian-practices-and-ethos/56177835)[Kaushalam](https://www.slideshare.net/slideshow/insights-from-indian-practices-and-ethos/56177835)[](https://www.slideshare.net/slideshow/insights-from-indian-practices-and-ethos/56177835)

[Excellence at](https://www.slideshare.net/slideshow/insights-from-indian-practices-and-ethos/56177835) work through self-motivation and self development with devotion and without attachment.

 [Co-operation](https://www.slideshare.net/slideshow/insights-from-indian-practices-and-ethos/56177835)

 [](https://www.slideshare.net/slideshow/insights-from-indian-practices-and-ethos/56177835)[It is a](https://www.slideshare.net/slideshow/insights-from-indian-practices-and-ethos/56177835) powerful instrument for team work and success in any enterprise involving collective work.