1. Maximum results with minimum efforts.
2. Higher efficiency.
3. Satisfaction of customers.
4. Better Workforce.
5. Relations with suppliers.
6. Better working conditions.
7. Contribution to national goals.
