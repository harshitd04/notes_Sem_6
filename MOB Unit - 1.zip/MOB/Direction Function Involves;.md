1. Leadership
2. Communication
3. Motivation
4. Supervision