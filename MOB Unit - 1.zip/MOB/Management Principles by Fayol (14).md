**The 14 management principles by Fayol are:**
1. Division of Work
2. Authority and Responsibility
3. Discipline
4. Unity of Command
5. Unity of Division
6. Subordination of Individual to General Interest
7. Remuneration of Personnel
8. Centralisation
9. Scalar Chain or Hierarchy
10. Order
11. Equity
12. Stability of Tenure of Personnel
13. Initiative
14. Esprit de Corps