1. Management is goal-oriented.
2. Management is a distinct and universal process.
3. is a continuous process.
4. Integrates human and other resources.
5. is intangible.
6. is situational.
7. is multi-disciplinary.
8. is a dynamic function.
9. is both a Science and an Art.
