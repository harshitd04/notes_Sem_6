1. Administrative/Functional Principles by Henry Fayol [14]
2. Scientific Principle of Management by Fredrick Taylor Winslow [5]
3. Bureaucratic Approach by Max Webex